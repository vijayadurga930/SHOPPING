package com.capgemini.ShoppingCart.Exception;

public class SCart extends Exception{
	
	public SCart(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		
	}

	public SCart(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	public SCart(String message) {
		super(message);
			}

	public SCart(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
